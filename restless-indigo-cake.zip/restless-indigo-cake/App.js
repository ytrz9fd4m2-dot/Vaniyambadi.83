import React from 'react';
import {
  SafeAreaView,
  View,
  Text,
  TextInput,
  ScrollView,
  TouchableOpacity,
  StyleSheet,
} from 'react-native';

const categories = [
  ['🚨', 'Emergency'],
  ['📍', 'Locations'],
  ['🛒', 'Shops'],
  ['⛽', 'Petrol Bunks'],
  ['🏥', 'Hospitals'],
  ['🏨', 'Hotels'],
  ['🛵', 'Delivery'],
  ['🏦', 'Banks & ATMs'],
  ['🏫', 'Schools'],
  ['🕌', 'Important Places'],
  ['🗺️', 'Nearby Places'],
  ['🎬', 'Reels'],
];

export default function App() {
  return (
    <SafeAreaView style={styles.container}>
      <ScrollView>
        <View style={styles.header}>
          <Text style={styles.title}>VANIYAMBADI</Text>
          <Text style={styles.subtitle}>LOCAL, ALL AROUND</Text>
        </View>

        <View style={styles.searchBox}>
          <TextInput
            placeholder="எதை தேடுகிறீர்கள்?"
            placeholderTextColor="#777"
            style={styles.search}
          />
        </View>

        <Text style={styles.heading}>Vaniyambadi 360</Text>

        <View style={styles.grid}>
          {categories.map(([icon, name]) => (
            <TouchableOpacity key={name} style={styles.card}>
              <Text style={styles.icon}>{icon}</Text>
              <Text style={styles.cardText}>{name}</Text>
            </TouchableOpacity>
          ))}
        </View>

        <View style={styles.banner}>
          <Text style={styles.bannerTitle}>AROUND YOUR CORNER</Text>
          <Text style={styles.bannerText}>
            Find shops, services and places around Vaniyambadi.
          </Text>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F5F8FC',
  },
  header: {
    backgroundColor: '#0757A0',
    padding: 24,
    paddingTop: 35,
  },
  title: {
    color: '#FFFFFF',
    fontSize: 30,
    fontWeight: '800',
  },
  subtitle: {
    color: '#D9ECFF',
    fontSize: 15,
    marginTop: 4,
    letterSpacing: 2,
  },
  searchBox: {
    padding: 16,
  },
  search: {
    backgroundColor: '#FFFFFF',
    borderRadius: 14,
    padding: 15,
    fontSize: 16,
    borderWidth: 1,
    borderColor: '#D8E0EA',
  },
  heading: {
    fontSize: 22,
    fontWeight: '700',
    marginHorizontal: 16,
    marginBottom: 12,
  },
  grid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    paddingHorizontal: 10,
  },
  card: {
    width: '29%',
    margin: '2%',
    backgroundColor: '#FFFFFF',
    borderRadius: 16,
    padding: 15,
    alignItems: 'center',
    elevation: 3,
  },
  icon: {
    fontSize: 28,
    marginBottom: 8,
  },
  cardText: {
    fontSize: 12,
    fontWeight: '600',
    textAlign: 'center',
  },
  banner: {
    margin: 16,
    padding: 20,
    backgroundColor: '#E7F1FF',
    borderRadius: 18,
  },
  bannerTitle: {
    fontSize: 18,
    fontWeight: '800',
  },
  bannerText: {
    marginTop: 6,
    fontSize: 14,
  },
});